resource "tls_private_key" "ssh_key" {
  algorithm = "RSA"
  rsa_bits  = 4096
}

# Create an AWS key pair from the generated key
resource "aws_key_pair" "ec2_key_pair" {
  key_name   = "${local.streamlit_application_name}-key-${var.prefix}"
  public_key = tls_private_key.ssh_key.public_key_openssh
}

# Store the private key in AWS Secrets Manager
resource "aws_secretsmanager_secret" "ssh_key_secret" {
  name                    = "${local.streamlit_application_name}-ssh-key-${var.prefix}"
  description             = "SSH private key for Streamlit app EC2 instance"
  recovery_window_in_days = 0 # No recovery window for easy cleanup during testing
}

resource "aws_secretsmanager_secret_version" "ssh_key_secret_version" {
  secret_id     = aws_secretsmanager_secret.ssh_key_secret.id
  secret_string = tls_private_key.ssh_key.private_key_pem
}
