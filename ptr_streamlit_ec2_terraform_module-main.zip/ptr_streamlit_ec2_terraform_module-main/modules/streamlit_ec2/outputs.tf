locals {
  streamlit_app_key_file_name = "${local.streamlit_application_name}-key-${var.prefix}.pem"
}

output "ssh_instructions" {
  value       = <<-EOT
    To retrieve the SSH private key from Secrets Manager:

    rm -rf ${local.streamlit_app_key_file_name}
    aws secretsmanager get-secret-value --secret-id ${aws_secretsmanager_secret.ssh_key_secret.name} --query SecretString --output text > ${local.streamlit_app_key_file_name}
    chmod 400 ${local.streamlit_app_key_file_name}
    ssh -i ${local.streamlit_app_key_file_name} ec2-user@${aws_instance.streamlit_app.public_ip}

  EOT
  description = "Instructions for retrieving the SSH key and connecting to the instance"
}


output "streamlit_app_url" {
  value       = "http://${aws_instance.streamlit_app.public_dns}:8501"
  description = "URL to access the Streamlit application"
}

output "streamlit_app_http_url" {
  value       = "http://${aws_instance.streamlit_app.public_ip}:8501"
  description = "URL to access the Streamlit application over HTTP"
}

output "ami_id" {
  value       = data.aws_ami.amazon_linux_2.id
  description = "Latest Amazon Linux 2 AMI ID"
}