locals {
  streamlit_git_repo = replace(var.streamlit_git_repo, "https://", "https://oauth2:${var.github_token}@")
}

locals {
  additional_env_vars_string = join(" ", [for k, v in var.additional_env_vars : "${k}=${v}"])
}

locals {
  streamlit_application_name = replace(var.streamlit_application_name, " ", "_")
}

resource "aws_iam_instance_profile" "ec2_profile" {
  name = "${local.streamlit_application_name}-ec2profile-${var.prefix}"
  role = aws_iam_role.ec2_role.name
}


# Create security group for the EC2 instance
resource "aws_security_group" "streamlit_sg" {
  name        = "${local.streamlit_application_name}_sg-${var.prefix}"
  description = "Security group for Streamlit app ${local.streamlit_application_name}"

  # Allow inbound access to the Streamlit port (8501)
  ingress {
    from_port   = 8501
    to_port     = 8501
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Streamlit web access"
  }

  # Allow SSH access
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "SSH access"
  }

  # Allow HTTP access
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTP access"
  }

  # Allow HTTPS access
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTPS access"
  }

  # Allow all outbound traffic
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# Get the latest Amazon Linux 2 AMI
data "aws_ami" "amazon_linux_2" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-ecs-neuron-hvm-*kernel-6.1-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

resource "aws_instance" "streamlit_app" {
  ami                    = data.aws_ami.amazon_linux_2.id
  instance_type          = "t2.large"
  iam_instance_profile   = aws_iam_instance_profile.ec2_profile.name
  vpc_security_group_ids = concat([aws_security_group.streamlit_sg.id], var.additional_security_groups)
  key_name               = aws_key_pair.ec2_key_pair.key_name
  root_block_device {
    encrypted   = true
    volume_size = 30
  }

  user_data = <<-EOF
              #!/bin/bash

              echo 'export AWS_REGION=${var.aws_region}' >> /etc/profile
              echo 'GITHUB_TOKEN=${var.github_token}' >> /etc/environment
              echo 'AWS_REGION=${var.aws_region}' >> /etc/environment

              export GITHUB_TOKEN=${var.github_token}

              # Update system packages
              yum update -y

              export DOCKER_CONFIG=/usr/local/lib/docker
              mkdir -p "$DOCKER_CONFIG/cli-plugins"
              curl -SL https://github.com/docker/compose/releases/download/v2.39.2/docker-compose-linux-x86_64 -o "$DOCKER_CONFIG/cli-plugins/docker-compose"
              chmod +x "$DOCKER_CONFIG/cli-plugins/docker-compose"
              docker compose version

              # Install git
              yum install -y git

              # Install pip and Python development tools
              yum install -y python3-pip python3-devel nginx nano
              dnf install -y python3.11 python3.11-pip python3.11-devel

              git config --system url.https://oauth2:${var.github_token}@github.com/Capgemini-Innersource.insteadOf https://github.com/Capgemini-Innersource

              # Clone the repository
              git clone ${local.streamlit_git_repo} /home/ec2-user/streamlit_app

              yum remove -y python3-requests

              # Install dependencies
              cd /home/ec2-user/streamlit_app
              pip3.11 install -r requirements.txt

              # Install Streamlit if not in requirements
              pip3.11 install streamlit

              ln -s /usr/bin/python3.11 /usr/local/bin/python

              make start-all || true

              # Create update script
              cat > /home/ec2-user/update_app.sh << 'SCRIPTEOF'
              #!/bin/bash

              APP_DIR="/home/ec2-user/streamlit_app"
              REPO_URL="${local.streamlit_git_repo}"
              LOG_FILE="/var/log/app_updater.log"

              echo "$(date): Checking for updates..." >> $LOG_FILE

              # Navigate to app directory
              cd $APP_DIR

              # Store current commit hash
              CURRENT_HASH=$(git rev-parse HEAD)

              # Fetch the latest changes from the repository
              git fetch origin

              # Get the latest commit hash on the remote
              REMOTE_HASH=$(git rev-parse origin/main)

              # Compare the hashes
              if [ "$CURRENT_HASH" != "$REMOTE_HASH" ]; then
                echo "$(date): Updates found, updating application..." >> $LOG_FILE

                # Pull the latest changes
                git pull origin main

                # Install any new dependencies
                pip3.11 install -r requirements.txt

                make start-all || true

                # Restart the Streamlit service
                sudo systemctl restart streamlit

                echo "$(date): Application updated successfully!" >> $LOG_FILE
              else
                echo "$(date): No updates found." >> $LOG_FILE
              fi
              SCRIPTEOF

              # Make script executable
              chmod +x /home/ec2-user/update_app.sh
              chown ec2-user:ec2-user /home/ec2-user/update_app.sh

              chown -R ec2-user:ec2-user /home/ec2-user/streamlit_app
              git config --global --add safe.directory /home/ec2-user/streamlit_ap

              # Create the auto-updater service
              cat > /etc/systemd/system/app-updater.service << 'SERVICEEOF'
              [Unit]
              Description=Streamlit App Auto-Updater Service
              After=network.target

              [Service]
              Type=simple
              User=ec2-user
              ExecStart=/bin/bash -c 'while true; do /home/ec2-user/update_app.sh; sleep 300; done'
              Restart=always

              [Install]
              WantedBy=multi-user.target
              SERVICEEOF

              # Setup systemd service to run Streamlit on startup
              cat > /etc/systemd/system/streamlit.service << 'SERVICEEOF'
              [Unit]
              Description=Streamlit Service
              After=network.target

              [Service]
              User=ec2-user
              WorkingDirectory=/home/ec2-user/streamlit_app/${var.streamlit_app_directory}
              ExecStart=/bin/bash -c 'for kv in ${local.additional_env_vars_string}; do export "$kv"; done; export AWS_REGION=${var.aws_region};export GITHUB_TOKEN=${var.github_token};export APP_ENV=${var.app_env};/usr/local/bin/streamlit run ${var.streamlit_app_entry_script} --server.port=${var.streamlit_app_port} --server.address=0.0.0.0'
              Restart=always

              [Install]
              WantedBy=multi-user.target
              SERVICEEOF

              # Create log file and set permissions
              touch /var/log/app_updater.log
              chown ec2-user:ec2-user /var/log/app_updater.log

              # Start services
              systemctl daemon-reload
              systemctl enable streamlit
              systemctl start streamlit
              systemctl enable app-updater
              systemctl start app-updater

              # Add ec2-user to log group
              usermod -a -G adm ec2-user

              # Configure Nginx as a reverse proxy for Streamlit
              cat > /etc/nginx/conf.d/streamlit.conf << 'NGINXEOF'
              server {
                  listen 80;
                  server_name ${var.domain_name};  # Will match any hostname

                  location / {
                      proxy_pass http://localhost:8501/;
                      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                      proxy_set_header Host $http_host;
                      proxy_set_header X-Real-IP $remote_addr;
                      proxy_http_version 1.1;
                      proxy_set_header Upgrade $http_upgrade;
                      proxy_set_header Connection "upgrade";
                      proxy_read_timeout 86400;
                  }
              }
              NGINXEOF

              # Start Nginx
              pkill -f nginx & wait $!
              systemctl enable nginx
              systemctl start nginx

              # update the DNS record
              curl https://api.dnsexit.com/dns/ud/?apikey=914XEhq7O8iE6p4pF217NJbi53vXNb -d host=${var.domain_name}

              sleep 30
              resolvectl flush-caches
              echo "Waiting for DNS to propagate..."
              sleep 30

              yum update -y
              yum install -y certbot
              yum install -y python3-certbot-nginx
              certbot --nginx -d ${var.domain_name}  --non-interactive --agree-tos --email admin@gmail.com

              EOF

  tags = {
    Name = "${local.streamlit_application_name}-${var.prefix}"
  }
}
