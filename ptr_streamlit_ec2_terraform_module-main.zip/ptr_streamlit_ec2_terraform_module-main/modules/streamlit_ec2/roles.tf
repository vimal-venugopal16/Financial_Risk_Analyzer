# Create IAM role for the EC2 instance
resource "aws_iam_role" "ec2_role" {
  name = "${local.streamlit_application_name}-${var.prefix}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })
}

# Create custom policy for Bedrock invoke_agent permissions
resource "aws_iam_policy" "bedrock_invoke_agent_policy" {
  name        = "${local.streamlit_application_name}-BedRockInvoke-${var.prefix}"
  description = "Allows invoking Bedrock agents"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = [
          "bedrock:InvokeAgent",
          "bedrock:InvokeModel",
          "bedrock:ListAgents",
          "bedrock:GetAgent",
          "bedrock:ListAgentAliases",
          "bedrock:InvokeModelWithResponseStream"
        ]
        Effect   = "Allow"
        Resource = "*"
      },
      {
        Action = [
          "s3:PutObject",
          "s3:GetObject",
          "s3:ListBucket",
          "s3:DeleteObject"
        ]
        Effect = "Allow"
        Resource = [
          "*"
        ]
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "ec2_bedrock" {
  role       = aws_iam_role.ec2_role.name
  policy_arn = aws_iam_policy.bedrock_invoke_agent_policy.arn
}