variable "streamlit_git_repo" {
  description = "Git repository URL for the Streamlit application"
  type        = string
}

variable "streamlit_git_branch" {
  description = "Git branch for the Streamlit application"
  type        = string
  default     = "main"
}

variable "domain_name" {
  description = "Domain name for the Streamlit application"
  type        = string
}

variable "aws_region" {
  description = "AWS region to deploy the Streamlit application"
  type        = string
  default     = "us-east-1"
}

variable "prefix" {
  description = "Prefix for the Streamlit application"
  type        = string
}

variable "github_token" {
  description = "GitHub token for accessing the Streamlit application repository"
  type        = string
}

variable "additional_security_groups" {
  description = "List of additional security group IDs to attach to the EC2 instance"
  type        = list(string)
  default     = []
}

variable "streamlit_app_directory" {
  description = "Sub directory path where the streamlit entry script is present"
  type        = string
  default     = ""
}

variable "streamlit_app_entry_script" {
  description = "Streamlit app python entry script"
  type        = string
  default     = "app.py"
}

variable "streamlit_app_port" {
  description = "Streamlit app port"
  type        = number
  default     = 8501
}

variable "additional_env_vars" {
  type    = map(string)
  default = {}
}

variable "streamlit_application_name" {
  type = string
}

variable "app_env" {
  type = string
}