module "streamlit_ec2" {
  source                     = "./modules/streamlit_ec2"
  domain_name                = var.domain_name
  github_token               = var.github_token
  prefix                     = var.prefix
  streamlit_git_repo         = var.streamlit_git_repo
  streamlit_app_entry_script = var.streamlit_app_entry_script
  streamlit_app_directory    = var.streamlit_app_directory
  streamlit_application_name = var.streamlit_application_name
  streamlit_app_port         = var.streamlit_app_port
  aws_region                 = var.aws_region
  streamlit_git_branch       = var.streamlit_git_branch
  additional_security_groups = var.additional_security_groups
  additional_env_vars        = var.additional_env_vars
  app_env                    = var.app_env
}