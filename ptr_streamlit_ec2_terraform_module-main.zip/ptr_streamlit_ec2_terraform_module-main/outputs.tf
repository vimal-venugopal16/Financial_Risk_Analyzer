output "ssh_instructions" {
  value = module.streamlit_ec2.ssh_instructions
}

output "streamlit_app_url" {
  value       = module.streamlit_ec2.streamlit_app_url
  description = "URL to access the Streamlit application"
}

output "streamlit_app_http_url" {
  value       = module.streamlit_ec2.streamlit_app_http_url
  description = "URL to access the Streamlit application over HTTP"
}